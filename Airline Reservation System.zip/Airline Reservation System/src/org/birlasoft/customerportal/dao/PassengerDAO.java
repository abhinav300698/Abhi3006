package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.birlasoft.customrportal.model.PassengerVO;
import com.birlasoft.customrportal.util.ConnectionDB;

//DATA ACCESS LAYER
public class PassengerDAO {

	/* addCustomer method to add customer data in custom
	 * 
	 */
	public static int addPassenger(PassengerVO passenger)
	{    int result=0;
		Connection con =null;
		String QUERY="insert into passenger values(?,?,?)";
		try
		{
		ConnectionDB.loadDrivers();
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, passenger.getpassengerId());
		                 pStat.setString(2, passenger.getpassengerName());
		                 pStat.setString(3, passenger.getflightno());
		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	
	public static int removePassenger(PassengerVO passenger)
	{    int result=0;
		Connection con =null;
		String QUERY="delete  from passenger where passenger_id=?"
				+ "";
		try
		{
			
		ConnectionDB.loadDrivers();
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, passenger.getpassengerId());
		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	
	public static int searchPassenger(PassengerVO passenger)
	{    int result=0;
		Connection con =null;
		String QUERY="select *  from passenger where passenger_id=?"
				+ "";
		try
		{
			
		ConnectionDB.loadDrivers();
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, passenger.getpassengerId());
		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	
	public static int updatePassenger(PassengerVO passenger)
	{    int result=0;
		Connection con =null;
		String QUERY="update passenger set passengerName='Kanishk.S' where passengerId='?'";
				
		try
		{
			
		ConnectionDB.loadDrivers();
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, passenger.getpassengerId());
		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	



	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}


