package org.birlasoft.customerportal.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.birlasoft.customrportal.model.FoodVO;
import com.birlasoft.customrportal.util.ConnectionDB;

public class FoodDAO {

	public static int reserveFood(FoodVO food)
	{    int result=0;
		Connection con =null;
		String QUERY="insert into Food_Order values(?,?,?)";
		try
		{
		ConnectionDB.loadDrivers();
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, food.getairline());
		                 pStat.setString(2, food.getfoodorder());
		                 pStat.setString(3, food.gettravel());

		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}

	
		
	

	
}
