package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.birlasoft.customrportal.model.BookingVO;
import com.birlasoft.customrportal.util.ConnectionDB;

public class BookingDAO {

	public static int reservePassenger(BookingVO book)
	{    int result=0;
		Connection con =null;
		String QUERY="insert into booking values(?,?,?,?)";
		try
		{
		ConnectionDB.loadDrivers();
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, book.getBookId());
		                 pStat.setString(2, book.getstarting());
		                 pStat.setString(3, book.getDestination());
		                 pStat.setString(4, book.getPassengerId());

		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	
	
}
