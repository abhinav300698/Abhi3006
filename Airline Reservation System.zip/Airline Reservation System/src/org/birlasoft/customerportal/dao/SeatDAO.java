package org.birlasoft.customerportal.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.birlasoft.customrportal.model.SeatVO;
import com.birlasoft.customrportal.util.ConnectionDB;


public class SeatDAO {

	public static int reserveSeat(SeatVO seat)
	{    int result=0;
		Connection con =null;
		String QUERY="insert into seat_booking values(?,?,?)";
		try
		{
		ConnectionDB.loadDrivers();
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();

		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1,seat.getConfirmation());
		                 pStat.setString(2,seat.getmobileno());
		                 pStat.setString(3,seat.getdestination());
		                 result= pStat.executeUpdate();
		                
		}
		catch(PassengerDatabaseException e)
		{
			System.out.println("problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	
	
}

