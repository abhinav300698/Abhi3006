package org.birlasoft.customerportal.dao;

public class PassengerDatabaseException extends Exception {
	
	
	public PassengerDatabaseException(String msg)
	{
		super(msg);
	}
	public PassengerDatabaseException(Throwable error)
	{
		super(error);
	}
	 
	
	

}
