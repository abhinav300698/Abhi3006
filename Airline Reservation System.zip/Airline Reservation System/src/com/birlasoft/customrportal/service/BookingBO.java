package com.birlasoft.customrportal.service;

import com.birlasoft.customrportal.model.BookingVO;

public class BookingBO {

	public static boolean  validateBooking(BookingVO  booking)
	{
		boolean result=false;
		
		String bookId = booking.getBookId();
		
		if(bookId.substring(0,2).equals("B-"))
		{
			result=true;
			
		}
		
		return result;
	}
	
}

