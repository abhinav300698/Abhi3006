package com.birlasoft.customrportal.service;

import com.birlasoft.customrportal.model.PassengerVO;

public class PassengerBO {

	public static boolean  validatePassenger(PassengerVO  passenger)
	{
		boolean result=false;
		
		String passengerId = passenger.getpassengerId();
		
		if(passengerId.substring(0,2).equals("P-"))
		{
			result=true;
			
		}
		
		return result;
	}
	
}
