package com.birlasoft.customrportal.model;

public class SeatVO {
	
	private String Confirmation;
	private String mobileno;
	private String destination;
	
	public SeatVO(String Confirmation, String mobileno,String destination) {
		super();
		this.Confirmation =Confirmation;
		this.mobileno=mobileno;
		this.destination=destination;
		
	}

	public SeatVO(String Confirmation) {
		super();
		this.Confirmation = Confirmation;
	}

	/**
	 * @return the SeatId
	 */
	public String getConfirmation() {
		return Confirmation;
	}

	/**
	 * @param confirm your seat 
	 */
	public void setConfirmationName(String Confirmation) {
		this.Confirmation =Confirmation;
	}

	
	/**
	 * @return the mobileno
	 */
	public String getmobileno() {
		return mobileno;
	}
	
	public void setmobileno(String mobileno) {
		this.mobileno=mobileno;
	}
	
	public String getdestination() {
		return destination;
	}
	public void setdestination(String destination) {
		this.destination=destination;
	}
	
}



	

