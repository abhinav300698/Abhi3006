package com.birlasoft.customrportal.model;


public class LoginVO {

	/**
	 *     LoginVO  
	 *       get/set
	 *       userName /password
	 *       getUSerNAme() method 
	 * 
	 * 
	 */
	private String userName;
	private String Password;
	
	/*
	 * 
	 * 
	 * 
	 */
	public String getUserName() {
		return userName;
	}
	public LoginVO(String userName, String password) {
		super();
		this.userName = userName;
		Password = password;
	}
	public LoginVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "LoginVO [userName=" + userName + ", Password=" + Password + "]";
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

}
