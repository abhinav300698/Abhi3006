
package com.birlasoft.customrportal.model;
// VALUE OBJECT  -> Domain Object -> TRANSFER OBJECT
// POJO
//    object of customer are not able to compare
public  class PassengerVO implements Comparable<PassengerVO>{
	
	private String passengerId;
	private String passengerName;
	private String flightno;
	public PassengerVO() {
		super();
		
	}
	
	
	public PassengerVO(String passengerId) {
		super();
		this.passengerId = passengerId;
	}


	public  PassengerVO(String passengerId, String passengerName,
			String flightno) {
		super();
		this.passengerId = passengerId;
		this.passengerName=passengerName;
		this.flightno=flightno;
	}
	public String getpassengerId() {
		return passengerId;
	}
	public void passengerId(String passengerId) {
		this.passengerId = passengerId;
	}
	public String getpassengerName() {
		return passengerName;
	}
	public void setpassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getflightno() {
		return flightno;
	}
	public void setflightno(String flightno) {
		this.flightno = flightno;
	}
	//@Override // represent object in string format
	public String toString() {
		return "PassengerVO [passengerId=" + passengerId + ", passengerName="
				+ passengerName + ", flightno=" + flightno + "]";
	}
	@Override
	public int compareTo(PassengerVO secondObj	) {
		
		int result=0;
		String firstObjName= this.getpassengerName();
		   String secondObjName= secondObj.getpassengerName();
		
		   result=  firstObjName.compareTo(secondObjName);
		   
		return result;
	}
	
	 

}
