package com.birlasoft.customrportal.model;

public class BookingVO {
	
	private String bookId;
	private String starting;
	private String destination;
	private String passengerId;
	
	public BookingVO(String bookId, String starting, String destination, String passengerId) {
		super();
		this.bookId = bookId;
		this.starting = starting;
		this.destination = destination;
		this.passengerId = passengerId;
	}

	public BookingVO(String bookId) {
		super();
		this.bookId = bookId;
	}

	/**
	 * @return the bookId
	 */
	public String getBookId() {
		return bookId;
	}

	/**
	 * @param bookId the bookId to set
	 */
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	/**
	 * @return the source
	 */
	public String getstarting() {
		return starting;
	}

	/**
	 * @param origin the origin to set
	 */
	public void setstarting(String starting) {
		this.starting = starting;
	}

	/**
	 * @return the destination
	 */
	public String getDestination() {
		return destination;
	}

	/**
	 * @param destination the destination to set
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}

	/**
	 * @return the passengerId
	 */
	public String getPassengerId() {
		return passengerId;
	}

	/**
	 * @param passengerId the passengerId to set
	 */
	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}
	
	

}
