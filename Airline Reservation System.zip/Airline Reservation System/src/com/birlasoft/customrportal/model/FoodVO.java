package com.birlasoft.customrportal.model;
public class FoodVO {
	private String airline;
	private String foodorder;
	private String travel;
	
	
	public FoodVO(String airline,String foodorder, String travel) {
		super();
		this.airline=airline;
		this.foodorder=foodorder;
		this.travel= travel;
		
	}
	public FoodVO(String airline) {
		super();
		this.airline=airline;
	}

	public String getairline() {
		return airline;
	}
	 

	public void setairline(String airline) {
		this.airline=airline;
	}

	/**
	 * @return the order
	 */
	public String getfoodorder() {
		return foodorder;
	}

	/**
	 * @param orer the order to set
	 */
	public void setfoodorder(String foodorder) {
		this.foodorder=foodorder;
	}

	/**
	 * @return the travel mode
	 */
	public String gettravel() {
		return travel;
	}

	/**
	 * @param travel the travel to set
	 */
	public void settravel(String travel) {
		this.travel = travel;
	}

	

}

