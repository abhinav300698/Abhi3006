package PROJECT.src;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.birlasoft.customerportal.dao.PassengerDAO;
import org.birlasoft.customerportal.dao.BookingDAO;
import org.birlasoft.customerportal.dao.SeatDAO;
import org.birlasoft.customerportal.dao.LoginCheckException;                
import org.birlasoft.customerportal.dao.LoginDAO;
import org.birlasoft.customerportal.dao.FoodDAO;

import com.birlasoft.customrportal.model.PassengerVO;
import com.birlasoft.customrportal.model.BookingVO;
import com.birlasoft.customrportal.model.SeatVO;
import com.birlasoft.customrportal.model.FoodVO;
import com.birlasoft.customrportal.model.LoginVO;
import com.birlasoft.customrportal.service.PassengerBO;
import com.birlasoft.customrportal.service.BookingBO;
import com.birlasoft.customrportal.service.LoginBO;



public class Passenger {
	
	
	public static <NString> void main(String[] args) {
	     
		
		     Scanner  input= new Scanner(System.in);
		   //Login Check for user authentication
	         String loginReq="yes";
	         int loginCheck=0;
	         
	         
	          LoginDAO loginDAO = new LoginDAO();
	         
		     while(loginReq.equalsIgnoreCase("yes"))
		     {
	System.out.println("\n Login ");	     
		     
	System.out.println("\n\n Please Enter your Credientials ");	
		  
	System.out.println("\nUser Name:");
	         String userName=input.next();
	System.out.println("\nPassword Name:");   
	         String password=input.next();
	         
	     LoginVO login = new LoginVO(userName,password);    
	         
		 boolean  loginValidate= LoginBO.loginValidate(login);
		  
		 if(loginValidate) // business logic success LoginBO
		 {
			 try
			 {
			 loginCheck = LoginDAO.loginCheck(login);
			 }
			 catch(LoginCheckException e)
			 {
				 System.out.println(e);
			 }
			 if(loginCheck==1)
			 {
				 System.out.println("login check sucesss");
				 break;
			 }
		 }
		 
		   System.out.println("Login Failed. please enter correct credentials ");
		   
		   
		   
		     }
	         boolean PassengerMenu=true;
		     while (PassengerMenu)
		     {
		     System.out.println("Passenger Services Available :\n\n");
		     
		     System.out.println("Passenger Information :press 1");
		     System.out.println("Booking Information :press 2");
		     System.out.println("Food Order Services : press 3");
		     System.out.print("Boarding Pass seat confirmation :press 4");
		      
		     int userSelection =Integer.parseInt(input.next());
	         
		     switch(userSelection)
		     {
		     
		     case 1:System.out.println("Passenger Menu \n");
		     {
		     System.out.println("Add Passenger : press 1");
		     System.out.println("Remove Passenger : press 2");
		     System.out.println("Search Passenger: press 3");
		     System.out.println("Update Passenger: press 4");
		     int PassengerCheck =Integer.parseInt(input.next());
	                  
	         
		               if(PassengerCheck==1)
		               {
		    	 System.out.println("add Passenger details");
		    	   String passengerId= input.next();
		    	   String passengerName= input.next();
		    	   String flightno=input.next();
		    	   
		    	   
		    	   
		    	   PassengerVO passenger = new PassengerVO(passengerId,passengerName,flightno);
		    	   
		    	boolean result=   PassengerBO.validatePassenger(passenger);
		    	   
		    	   if(result)
		    	   {
		    		  
		    		   //sending data to database
		    		   int daoResult=PassengerDAO.addPassenger(passenger);
		    		   
		    		   if(daoResult>=1)
		    		   {
		    		   System.out.println("Passenger added in database");
		    		   }
		    		   else
		    		   {
		    			   System.out.println("  problem in adding Passenger");
		    		   }
		    	   }
		    	   else
		    	   {
		    		   System.out.println("problem in validating Passenger");
		    	   }
		       
		               } //end of customer if
		               
		               if(PassengerCheck==2)
		               {
		            	   
		            	   System.out.println("Remove Passenger ");
		            	   System.out.println("Enter passenger id");
				    	   String passengerId= input.next();
		            	   
		            	   PassengerVO passenger = new PassengerVO(passengerId);
		            	   
		            	   int daoResult=PassengerDAO.removePassenger(passenger);
		            	   
		            	   if(daoResult>=1)
			    		   {
			    		   System.out.println("Passenger removed in database");
			    		   }
			    		   else
			    		   {
			    			   System.out.println("  problem in removing Passenger");
			    		   }
		            
		               }//end of customer if for removing passenger
		               
		               if(PassengerCheck==3)
		               {
		            	   
		            	   System.out.println("Search Passenger ");
		            	   System.out.println("Enter passenger id");
				    	   String passengerId= input.next();
		            	   
		            	   PassengerVO passenger = new PassengerVO(passengerId);
		            	   
		            	   int daoResult=PassengerDAO.searchPassenger(passenger);
		            	   
		            	   if(daoResult>=1)
			    		   {
			    		   System.out.println("Passenger record available");
			    		   }
			    		   else
			    		   {
			    			   System.out.println(" No record Of Passenger");
			    		   }
		            
		               }//end of customer if for removing passenger
		               
		               
		     
		     
		     if(PassengerCheck==4)
             {
          	   
          	   System.out.println("Update Passenger ");
          	   System.out.println("Enter passenger id");
		    	   String passengerId= input.next();
          	   
          	   PassengerVO passenger = new PassengerVO(passengerId);
          	   
          	   int daoResult=PassengerDAO.searchPassenger(passenger);
          	   
          	   if(daoResult>=1)
	    		   {
	    		   System.out.println("Passenger Updated ");
	    		   }
	    		   else
	    		   {
	    			   System.out.println(" Not Updated");
	    		   }
          
             }//end of customer if for Update passenger
             
             break;
		     }
		     
		     
		     
		     
		     
		     
		     
		    
		     case 2:
		     {
		    	 System.out.println("Book Passeneger");
		    	 System.out.println("Enter Booking Id");
		    	 String book_id = input.next();
		    	 
		    	 System.out.println("Enter origin");
		    	 String starting = input.next(); 
		    	 
		    	 System.out.println("Enter Destination");
		    	 String destination = input.next();
		    	 
		    	 System.out.println("Enter passenger Id");
		    	 String passengerId = input.next();
		    	 
		    	 BookingVO book = new BookingVO(book_id,starting,destination,passengerId);
		    	 
		    	 int daoResult = BookingDAO.reservePassenger(book);
		    	 boolean result= BookingBO.validateBooking(book);
		    	 
		    	 
          	   if(daoResult>=1)
	    		   {
	    		   System.out.println("Passenger reserved");
	    		   }
	    		   else
	    		   {
	    			   System.out.println(" Problem in Booking Passenger");
	    		   }
		    	 
		    	
		     break;
		     } //end of case 2
		    	    
		     case 3:
		     {
		    	 System.out.println("Food Order Services");
		    	 System.out.println("Enter your airline");
		    	 String airline=input.next();
		    	 
                 System.out.print("Enter the type of food");
                 String foodorder= input.next();
                 
                 System.out.print("Enter your flight travel mode");
                 String travel=input.next();
                         
                 FoodVO food= new FoodVO(airline,foodorder,travel);
                 //sending data to database
     		      int daoResult=FoodDAO.reserveFood(food);
     		    		   
                        

                        if(daoResult>=1)
                         {
                         System.out.print("Your Order has been Received.plzz don't forget to collect your order from your airline staff,Happy and Safe journey");
                         }
                         else
                         {
                         System.out.print("Problem in Adding Order");
                          }
                         break;
                        } //end of case 3
                        
                       
	 case 4:
     {
           System.out.print("Boarding pass seat Confirmation");
           
           System.out.print("For Seat Confirmation press Yes");
           String Confirmation=input.nextLine();
           
           System.out.println("Enter your destination.");
		   String destination=input.nextLine();
		   
		   System.out.println("Enter your mobile number");
		   String mobileno=input.nextLine();
		      
	         
           
            SeatVO seat = new SeatVO(Confirmation,mobileno,destination);
                int daoResult=SeatDAO.reserveSeat(seat);
                if(daoResult>=1)
                 {
                 System.out.print("Your Seat has been confirmed Kindly check your boarding pass for your Seat location.Happy and Safe journey");
                 }
                 else
                 {
                 System.out.print("Problem in Confirming Seat");
                  }
		     
                 break;
     }//end of case 4
	 case 5:
	 {
		 System.out.print("Thank You,Happy and Safe Journey");
	 }
		     
}//end of case 5
}//end of switch
}//end of case 4

		     } 
		     
		     
		     
		     
                    

	


                        
		     
		     
		     
		     
	
	